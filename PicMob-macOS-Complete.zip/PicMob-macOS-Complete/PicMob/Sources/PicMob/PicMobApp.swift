//
//  PicMobApp.swift
//  PicMob
//
//  Created by PicMob Team on 2025-01-01.
//  Copyright © 2025 PicMob Team. All rights reserved.
//

import SwiftUI
import AppKit

@main
struct PicMobApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .preferredColorScheme(.dark) // Mafia edge dark theme
                .background(PicMobTheme.primaryBackground)
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified(showsTitle: false))
        .commands {
            PicMobCommands()
        }
        
        Settings {
            SettingsView()
                .environmentObject(appState)
        }
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Configure app appearance for mafia edge theme
        NSApp.appearance = NSAppearance(named: .darkAqua)
        
        // Set up file associations
        setupFileAssociations()
        
        // Initialize AI models
        Task {
            await AIModelManager.shared.loadModels()
        }
        
        // Configure window appearance
        configureWindowAppearance()
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
    
    func application(_ sender: NSApplication, openFile filename: String) -> Bool {
        // Handle file opening from Finder
        let url = URL(fileURLWithPath: filename)
        NotificationCenter.default.post(name: .openFile, object: url)
        return true
    }
    
    private func setupFileAssociations() {
        // Register supported file types
        let supportedTypes = ImageFormat.allCases.map { $0.uti }
        
        // Configure document types in Info.plist
        // This is handled in the Info.plist file
    }
    
    private func configureWindowAppearance() {
        // Set up custom window styling for mafia edge theme
        if let window = NSApp.windows.first {
            window.titlebarAppearsTransparent = true
            window.titleVisibility = .hidden
            window.backgroundColor = NSColor(PicMobTheme.primaryBackground)
        }
    }
}

// MARK: - Menu Commands
struct PicMobCommands: Commands {
    var body: some Commands {
        CommandGroup(after: .newItem) {
            Button("Open Image...") {
                openImageFile()
            }
            .keyboardShortcut("o", modifiers: .command)
            
            Button("Open Folder...") {
                openFolder()
            }
            .keyboardShortcut("o", modifiers: [.command, .shift])
        }
        
        CommandGroup(after: .importExport) {
            Button("Export Image...") {
                exportCurrentImage()
            }
            .keyboardShortcut("e", modifiers: .command)
            
            Divider()
            
            Button("Batch Process...") {
                showBatchProcessor()
            }
            .keyboardShortcut("b", modifiers: [.command, .shift])
        }
        
        CommandMenu("Image") {
            Button("Zoom In") {
                zoomIn()
            }
            .keyboardShortcut("+", modifiers: .command)
            
            Button("Zoom Out") {
                zoomOut()
            }
            .keyboardShortcut("-", modifiers: .command)
            
            Button("Actual Size") {
                actualSize()
            }
            .keyboardShortcut("0", modifiers: .command)
            
            Button("Fit to Window") {
                fitToWindow()
            }
            .keyboardShortcut("9", modifiers: .command)
            
            Divider()
            
            Button("Rotate Left") {
                rotateLeft()
            }
            .keyboardShortcut("l", modifiers: [.command, .option])
            
            Button("Rotate Right") {
                rotateRight()
            }
            .keyboardShortcut("r", modifiers: [.command, .option])
            
            Divider()
            
            Button("AI Upscale 2x") {
                aiUpscale(factor: 2)
            }
            .keyboardShortcut("2", modifiers: [.command, .shift])
            
            Button("AI Upscale 4x") {
                aiUpscale(factor: 4)
            }
            .keyboardShortcut("4", modifiers: [.command, .shift])
        }
        
        CommandGroup(after: .help) {
            Button("PicMob Help") {
                showHelp()
            }
            .keyboardShortcut("?", modifiers: .command)
            
            Button("Report Issue") {
                reportIssue()
            }
            
            Button("Join Beta Program") {
                joinBeta()
            }
        }
    }
    
    private func openImageFile() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowedContentTypes = ImageFormat.allCases.compactMap { $0.contentType }
        
        if panel.runModal() == .OK, let url = panel.url {
            NotificationCenter.default.post(name: .openFile, object: url)
        }
    }
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        
        if panel.runModal() == .OK, let url = panel.url {
            NotificationCenter.default.post(name: .openFolder, object: url)
        }
    }
    
    private func exportCurrentImage() {
        NotificationCenter.default.post(name: .exportImage, object: nil)
    }
    
    private func showBatchProcessor() {
        NotificationCenter.default.post(name: .showBatchProcessor, object: nil)
    }
    
    private func zoomIn() {
        NotificationCenter.default.post(name: .zoomIn, object: nil)
    }
    
    private func zoomOut() {
        NotificationCenter.default.post(name: .zoomOut, object: nil)
    }
    
    private func actualSize() {
        NotificationCenter.default.post(name: .actualSize, object: nil)
    }
    
    private func fitToWindow() {
        NotificationCenter.default.post(name: .fitToWindow, object: nil)
    }
    
    private func rotateLeft() {
        NotificationCenter.default.post(name: .rotateLeft, object: nil)
    }
    
    private func rotateRight() {
        NotificationCenter.default.post(name: .rotateRight, object: nil)
    }
    
    private func aiUpscale(factor: Int) {
        NotificationCenter.default.post(name: .aiUpscale, object: factor)
    }
    
    private func showHelp() {
        if let url = URL(string: "https://picmob.app/help") {
            NSWorkspace.shared.open(url)
        }
    }
    
    private func reportIssue() {
        if let url = URL(string: "https://picmob.app/support") {
            NSWorkspace.shared.open(url)
        }
    }
    
    private func joinBeta() {
        if let url = URL(string: "https://picmob.app/beta") {
            NSWorkspace.shared.open(url)
        }
    }
}

// MARK: - Notification Names
extension Notification.Name {
    static let openFile = Notification.Name("openFile")
    static let openFolder = Notification.Name("openFolder")
    static let exportImage = Notification.Name("exportImage")
    static let showBatchProcessor = Notification.Name("showBatchProcessor")
    static let zoomIn = Notification.Name("zoomIn")
    static let zoomOut = Notification.Name("zoomOut")
    static let actualSize = Notification.Name("actualSize")
    static let fitToWindow = Notification.Name("fitToWindow")
    static let rotateLeft = Notification.Name("rotateLeft")
    static let rotateRight = Notification.Name("rotateRight")
    static let aiUpscale = Notification.Name("aiUpscale")
}

// MARK: - AI Model Manager
class AIModelManager {
    static let shared = AIModelManager()
    
    private init() {}
    
    func loadModels() async {
        // Load AI models for upscaling and object removal
        // This would be implemented with actual model loading
        print("Loading AI models...")
        
        // Simulate model loading time
        try? await Task.sleep(nanoseconds: 2_000_000_000) // 2 seconds
        
        print("AI models loaded successfully")
    }
}

