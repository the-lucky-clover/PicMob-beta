//
//  SidebarView.swift
//  PicMob
//
//  Created by PicMob Team.
//

import SwiftUI

struct SidebarView: View {
    @Binding var selectedImage: ImageInfo?
    @EnvironmentObject var appState: AppState
    @State private var selectedFolder: URL?
    @State private var folderImages: [URL] = []
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Header
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "crown.fill")
                        .font(.title2)
                        .foregroundColor(PicMobTheme.goldAccent)
                    
                    Text("PICMOB")
                        .font(PicMobTheme.titleFont)
                        .foregroundColor(PicMobTheme.goldAccent)
                }
                
                Text("The Family Business")
                    .font(PicMobTheme.captionFont)
                    .foregroundColor(PicMobTheme.mutedText)
                    .italic()
            }
            .padding(.horizontal)
            
            Divider()
                .background(PicMobTheme.borderColor)
            
            // Quick Actions
            VStack(alignment: .leading, spacing: 8) {
                Text("QUICK ACTIONS")
                    .font(PicMobTheme.bodyFont.weight(.semibold))
                    .foregroundColor(PicMobTheme.accentText)
                    .padding(.horizontal)
                
                VStack(spacing: 4) {
                    SidebarButton(
                        icon: "folder.badge.plus",
                        title: "Open Folder",
                        action: openFolder
                    )
                    
                    SidebarButton(
                        icon: "photo.badge.plus",
                        title: "Open Image",
                        action: openImage
                    )
                    
                    SidebarButton(
                        icon: "wand.and.rays",
                        title: "AI Enhance",
                        action: aiEnhance
                    )
                }
            }
            
            Divider()
                .background(PicMobTheme.borderColor)
            
            // Current Folder
            if let folder = selectedFolder {
                VStack(alignment: .leading, spacing: 8) {
                    Text("CURRENT FOLDER")
                        .font(PicMobTheme.bodyFont.weight(.semibold))
                        .foregroundColor(PicMobTheme.accentText)
                        .padding(.horizontal)
                    
                    Text(folder.lastPathComponent)
                        .font(PicMobTheme.captionFont)
                        .foregroundColor(PicMobTheme.mutedText)
                        .padding(.horizontal)
                        .lineLimit(1)
                    
                    ScrollView {
                        LazyVStack(spacing: 2) {
                            ForEach(folderImages, id: \.self) { imageURL in
                                FolderImageRow(
                                    url: imageURL,
                                    isSelected: selectedImage?.url == imageURL,
                                    onSelect: {
                                        Task {
                                            await loadImage(from: imageURL)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
                
                Divider()
                    .background(PicMobTheme.borderColor)
            }
            
            // Recent Files
            VStack(alignment: .leading, spacing: 8) {
                Text("RECENT")
                    .font(PicMobTheme.bodyFont.weight(.semibold))
                    .foregroundColor(PicMobTheme.accentText)
                    .padding(.horizontal)
                
                if appState.recentFiles.isEmpty {
                    Text("No recent files")
                        .font(PicMobTheme.captionFont)
                        .foregroundColor(PicMobTheme.mutedText)
                        .padding(.horizontal)
                } else {
                    ScrollView {
                        LazyVStack(spacing: 2) {
                            ForEach(appState.recentFiles, id: \.self) { url in
                                RecentFileRow(
                                    url: url,
                                    isSelected: selectedImage?.url == url,
                                    onSelect: {
                                        Task {
                                            await loadImage(from: url)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
            
            Spacer()
            
            // Status
            if appState.isProcessing {
                VStack(spacing: 8) {
                    ProgressView(value: appState.processingProgress)
                        .progressViewStyle(LinearProgressViewStyle(tint: PicMobTheme.goldAccent))
                    
                    Text("Processing...")
                        .font(PicMobTheme.captionFont)
                        .foregroundColor(PicMobTheme.mutedText)
                }
                .padding(.horizontal)
            }
        }
        .background(PicMobTheme.sidebarBackground)
        .onReceive(NotificationCenter.default.publisher(for: .openFolder)) { notification in
            if let url = notification.object as? URL {
                selectedFolder = url
                loadFolderImages(from: url)
            }
        }
    }
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        
        if panel.runModal() == .OK, let url = panel.url {
            selectedFolder = url
            appState.selectedFolder = url
            loadFolderImages(from: url)
        }
    }
    
    private func openImage() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowedContentTypes = ImageFormat.allCases.compactMap { $0.contentType }
        
        if panel.runModal() == .OK, let url = panel.url {
            Task {
                await loadImage(from: url)
            }
        }
    }
    
    private func aiEnhance() {
        // AI enhancement functionality
        if let image = selectedImage {
            appState.isProcessing = true
            // Simulate AI processing
            Task {
                for i in 0...100 {
                    await MainActor.run {
                        appState.processingProgress = Double(i) / 100.0
                    }
                    try? await Task.sleep(nanoseconds: 10_000_000) // 0.01 seconds
                }
                await MainActor.run {
                    appState.isProcessing = false
                    appState.processingProgress = 0.0
                }
            }
        }
    }
    
    private func loadFolderImages(from folder: URL) {
        Task {
            do {
                let contents = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
                let imageFiles = contents.filter { url in
                    let ext = url.pathExtension.lowercased()
                    return ImageFormat.allCases.contains { $0.rawValue == ext }
                }
                
                await MainActor.run {
                    folderImages = imageFiles.sorted { $0.lastPathComponent < $1.lastPathComponent }
                }
            } catch {
                print("Error loading folder contents: \(error)")
            }
        }
    }
    
    private func loadImage(from url: URL) async {
        do {
            let imageService = ImageService()
            let imageInfo = try await imageService.loadImage(from: url)
            await MainActor.run {
                selectedImage = imageInfo
                appState.currentImage = imageInfo
                appState.addRecentFile(url)
            }
        } catch {
            await MainActor.run {
                appState.errorMessage = "Failed to load image: \(error.localizedDescription)"
            }
        }
    }
}

struct SidebarButton: View {
    let icon: String
    let title: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .frame(width: 16)
                    .foregroundColor(PicMobTheme.goldAccent)
                
                Text(title)
                    .font(PicMobTheme.bodyFont)
                    .foregroundColor(PicMobTheme.primaryText)
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(Color.clear)
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
        .onHover { isHovered in
            // Add hover effect if needed
        }
    }
}

struct FolderImageRow: View {
    let url: URL
    let isSelected: Bool
    let onSelect: () -> Void
    
    var body: some View {
        Button(action: onSelect) {
            HStack {
                Image(systemName: "photo")
                    .frame(width: 16)
                    .foregroundColor(isSelected ? PicMobTheme.goldAccent : PicMobTheme.mutedText)
                
                Text(url.lastPathComponent)
                    .font(PicMobTheme.captionFont)
                    .foregroundColor(isSelected ? PicMobTheme.goldAccent : PicMobTheme.primaryText)
                    .lineLimit(1)
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 4)
            .background(isSelected ? PicMobTheme.goldAccent.opacity(0.1) : Color.clear)
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
    }
}

struct RecentFileRow: View {
    let url: URL
    let isSelected: Bool
    let onSelect: () -> Void
    
    var body: some View {
        Button(action: onSelect) {
            HStack {
                Image(systemName: "clock")
                    .frame(width: 16)
                    .foregroundColor(isSelected ? PicMobTheme.goldAccent : PicMobTheme.mutedText)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(url.lastPathComponent)
                        .font(PicMobTheme.captionFont)
                        .foregroundColor(isSelected ? PicMobTheme.goldAccent : PicMobTheme.primaryText)
                        .lineLimit(1)
                    
                    Text(url.deletingLastPathComponent().lastPathComponent)
                        .font(.caption2)
                        .foregroundColor(PicMobTheme.mutedText)
                        .lineLimit(1)
                }
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 4)
            .background(isSelected ? PicMobTheme.goldAccent.opacity(0.1) : Color.clear)
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    SidebarView(selectedImage: .constant(nil))
        .environmentObject(AppState())
        .frame(width: 250, height: 600)
}

