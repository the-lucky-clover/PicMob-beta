/**
 * PicMob Landing Page - Cloudflare Worker
 * Handles API endpoints, analytics, and serverless functions
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS headers for all responses
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    // Handle CORS preflight requests
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // API Routes
      if (path.startsWith('/api/')) {
        return await handleApiRequest(request, env, path);
      }

      // Static file serving (handled by Cloudflare Pages)
      return new Response('Not Found', { status: 404 });
    } catch (error) {
      console.error('Worker error:', error);
      return new Response(JSON.stringify({ error: 'Internal Server Error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  },
};

/**
 * Handle API requests
 */
async function handleApiRequest(request, env, path) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json',
  };

  switch (path) {
    case '/api/download-stats':
      return await getDownloadStats(env, corsHeaders);
    
    case '/api/newsletter':
      if (request.method === 'POST') {
        return await subscribeToNewsletter(request, env, corsHeaders);
      }
      break;
    
    case '/api/contact':
      if (request.method === 'POST') {
        return await handleContactForm(request, env, corsHeaders);
      }
      break;
    
    case '/api/analytics':
      if (request.method === 'POST') {
        return await trackAnalytics(request, env, corsHeaders);
      }
      break;
    
    case '/api/beta-signup':
      if (request.method === 'POST') {
        return await handleBetaSignup(request, env, corsHeaders);
      }
      break;
    
    default:
      return new Response(JSON.stringify({ error: 'Endpoint not found' }), {
        status: 404,
        headers: corsHeaders,
      });
  }
}

/**
 * Get download statistics
 */
async function getDownloadStats(env, corsHeaders) {
  try {
    const stmt = env.DB.prepare(`
      SELECT 
        platform,
        COUNT(*) as downloads,
        DATE(created_at) as date
      FROM downloads 
      WHERE created_at >= datetime('now', '-30 days')
      GROUP BY platform, DATE(created_at)
      ORDER BY date DESC
    `);
    
    const results = await stmt.all();
    
    // Aggregate data
    const stats = {
      total: 0,
      platforms: {
        windows: 0,
        macos: 0,
        ios: 0,
        android: 0
      },
      recent: results.results || []
    };
    
    results.results?.forEach(row => {
      stats.total += row.downloads;
      stats.platforms[row.platform.toLowerCase()] += row.downloads;
    });
    
    return new Response(JSON.stringify(stats), { headers: corsHeaders });
  } catch (error) {
    console.error('Download stats error:', error);
    return new Response(JSON.stringify({ error: 'Failed to fetch stats' }), {
      status: 500,
      headers: corsHeaders,
    });
  }
}

/**
 * Handle newsletter subscription
 */
async function subscribeToNewsletter(request, env, corsHeaders) {
  try {
    const { email, name } = await request.json();
    
    if (!email || !isValidEmail(email)) {
      return new Response(JSON.stringify({ error: 'Valid email required' }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    
    // Check if already subscribed
    const existing = await env.DB.prepare(
      'SELECT id FROM newsletter_subscribers WHERE email = ?'
    ).bind(email).first();
    
    if (existing) {
      return new Response(JSON.stringify({ message: 'Already subscribed' }), {
        headers: corsHeaders,
      });
    }
    
    // Insert new subscriber
    await env.DB.prepare(`
      INSERT INTO newsletter_subscribers (email, name, subscribed_at, status)
      VALUES (?, ?, datetime('now'), 'active')
    `).bind(email, name || '').run();
    
    // Track analytics
    await trackEvent(env, 'newsletter_signup', { email });
    
    return new Response(JSON.stringify({ message: 'Successfully subscribed' }), {
      headers: corsHeaders,
    });
  } catch (error) {
    console.error('Newsletter subscription error:', error);
    return new Response(JSON.stringify({ error: 'Subscription failed' }), {
      status: 500,
      headers: corsHeaders,
    });
  }
}

/**
 * Handle contact form submission
 */
async function handleContactForm(request, env, corsHeaders) {
  try {
    const { name, email, subject, message } = await request.json();
    
    if (!name || !email || !message) {
      return new Response(JSON.stringify({ error: 'All fields required' }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    
    if (!isValidEmail(email)) {
      return new Response(JSON.stringify({ error: 'Valid email required' }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    
    // Store contact form submission
    await env.DB.prepare(`
      INSERT INTO contact_submissions (name, email, subject, message, submitted_at, status)
      VALUES (?, ?, ?, ?, datetime('now'), 'new')
    `).bind(name, email, subject || 'General Inquiry', message).run();
    
    // Track analytics
    await trackEvent(env, 'contact_form', { email, subject });
    
    return new Response(JSON.stringify({ message: 'Message sent successfully' }), {
      headers: corsHeaders,
    });
  } catch (error) {
    console.error('Contact form error:', error);
    return new Response(JSON.stringify({ error: 'Failed to send message' }), {
      status: 500,
      headers: corsHeaders,
    });
  }
}

/**
 * Handle beta signup
 */
async function handleBetaSignup(request, env, corsHeaders) {
  try {
    const { email, platform, interests } = await request.json();
    
    if (!email || !isValidEmail(email)) {
      return new Response(JSON.stringify({ error: 'Valid email required' }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    
    // Check if already signed up
    const existing = await env.DB.prepare(
      'SELECT id FROM beta_signups WHERE email = ?'
    ).bind(email).first();
    
    if (existing) {
      return new Response(JSON.stringify({ message: 'Already signed up for beta' }), {
        headers: corsHeaders,
      });
    }
    
    // Insert beta signup
    await env.DB.prepare(`
      INSERT INTO beta_signups (email, platform, interests, signed_up_at, status)
      VALUES (?, ?, ?, datetime('now'), 'pending')
    `).bind(email, platform || 'all', JSON.stringify(interests || [])).run();
    
    // Track analytics
    await trackEvent(env, 'beta_signup', { email, platform });
    
    return new Response(JSON.stringify({ message: 'Successfully signed up for beta' }), {
      headers: corsHeaders,
    });
  } catch (error) {
    console.error('Beta signup error:', error);
    return new Response(JSON.stringify({ error: 'Beta signup failed' }), {
      status: 500,
      headers: corsHeaders,
    });
  }
}

/**
 * Track analytics events
 */
async function trackAnalytics(request, env, corsHeaders) {
  try {
    const { event, properties, userId } = await request.json();
    
    if (!event) {
      return new Response(JSON.stringify({ error: 'Event name required' }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    
    await trackEvent(env, event, properties, userId);
    
    return new Response(JSON.stringify({ message: 'Event tracked' }), {
      headers: corsHeaders,
    });
  } catch (error) {
    console.error('Analytics error:', error);
    return new Response(JSON.stringify({ error: 'Failed to track event' }), {
      status: 500,
      headers: corsHeaders,
    });
  }
}

/**
 * Track an analytics event
 */
async function trackEvent(env, event, properties = {}, userId = null) {
  try {
    await env.DB.prepare(`
      INSERT INTO analytics_events (event_name, properties, user_id, timestamp)
      VALUES (?, ?, ?, datetime('now'))
    `).bind(event, JSON.stringify(properties), userId).run();
  } catch (error) {
    console.error('Track event error:', error);
  }
}

/**
 * Validate email address
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Scheduled event handler for cleanup tasks
 */
export async function scheduled(event, env, ctx) {
  switch (event.cron) {
    case '0 0 * * *': // Daily at midnight
      await cleanupOldData(env);
      break;
  }
}

/**
 * Cleanup old data
 */
async function cleanupOldData(env) {
  try {
    // Clean up old analytics events (keep 90 days)
    await env.DB.prepare(`
      DELETE FROM analytics_events 
      WHERE timestamp < datetime('now', '-90 days')
    `).run();
    
    // Clean up old download records (keep 1 year)
    await env.DB.prepare(`
      DELETE FROM downloads 
      WHERE created_at < datetime('now', '-1 year')
    `).run();
    
    console.log('Cleanup completed successfully');
  } catch (error) {
    console.error('Cleanup error:', error);
  }
}

