-- PicMob Landing Page Database Schema
-- Cloudflare D1 Database

-- Newsletter subscribers
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    name TEXT,
    subscribed_at DATETIME NOT NULL,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'unsubscribed', 'bounced')),
    unsubscribe_token TEXT UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Contact form submissions
CREATE TABLE IF NOT EXISTS contact_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT,
    message TEXT NOT NULL,
    submitted_at DATETIME NOT NULL,
    status TEXT DEFAULT 'new' CHECK (status IN ('new', 'read', 'replied', 'closed')),
    ip_address TEXT,
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Beta program signups
CREATE TABLE IF NOT EXISTS beta_signups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    platform TEXT, -- 'windows', 'macos', 'ios', 'android', 'all'
    interests TEXT, -- JSON array of interests
    signed_up_at DATETIME NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'invited', 'active', 'declined')),
    invite_sent_at DATETIME,
    invite_token TEXT UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Download tracking
CREATE TABLE IF NOT EXISTS downloads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL, -- 'windows', 'macos', 'ios', 'android'
    version TEXT,
    ip_address TEXT,
    user_agent TEXT,
    referrer TEXT,
    country TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Analytics events
CREATE TABLE IF NOT EXISTS analytics_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_name TEXT NOT NULL,
    properties TEXT, -- JSON object
    user_id TEXT,
    session_id TEXT,
    ip_address TEXT,
    user_agent TEXT,
    referrer TEXT,
    timestamp DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- User sessions (for tracking unique visitors)
CREATE TABLE IF NOT EXISTS user_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    user_id TEXT,
    ip_address TEXT,
    user_agent TEXT,
    referrer TEXT,
    landing_page TEXT,
    country TEXT,
    started_at DATETIME NOT NULL,
    last_activity DATETIME NOT NULL,
    page_views INTEGER DEFAULT 1,
    duration_seconds INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- App store reviews/ratings (aggregated)
CREATE TABLE IF NOT EXISTS app_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL, -- 'windows', 'macos', 'ios', 'android'
    store TEXT NOT NULL, -- 'microsoft', 'apple', 'google'
    rating REAL NOT NULL,
    review_count INTEGER NOT NULL,
    average_rating REAL NOT NULL,
    last_updated DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Feature requests and feedback
CREATE TABLE IF NOT EXISTS feature_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT, -- 'feature', 'bug', 'improvement'
    priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    status TEXT DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'rejected')),
    votes INTEGER DEFAULT 0,
    submitted_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_newsletter_email ON newsletter_subscribers(email);
CREATE INDEX IF NOT EXISTS idx_newsletter_status ON newsletter_subscribers(status);
CREATE INDEX IF NOT EXISTS idx_contact_status ON contact_submissions(status);
CREATE INDEX IF NOT EXISTS idx_contact_submitted ON contact_submissions(submitted_at);
CREATE INDEX IF NOT EXISTS idx_beta_email ON beta_signups(email);
CREATE INDEX IF NOT EXISTS idx_beta_platform ON beta_signups(platform);
CREATE INDEX IF NOT EXISTS idx_beta_status ON beta_signups(status);
CREATE INDEX IF NOT EXISTS idx_downloads_platform ON downloads(platform);
CREATE INDEX IF NOT EXISTS idx_downloads_created ON downloads(created_at);
CREATE INDEX IF NOT EXISTS idx_analytics_event ON analytics_events(event_name);
CREATE INDEX IF NOT EXISTS idx_analytics_timestamp ON analytics_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_sessions_session_id ON user_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_sessions_started ON user_sessions(started_at);
CREATE INDEX IF NOT EXISTS idx_reviews_platform ON app_reviews(platform);
CREATE INDEX IF NOT EXISTS idx_features_status ON feature_requests(status);
CREATE INDEX IF NOT EXISTS idx_features_category ON feature_requests(category);

-- Create triggers for updated_at timestamps
CREATE TRIGGER IF NOT EXISTS update_newsletter_timestamp 
    AFTER UPDATE ON newsletter_subscribers
    BEGIN
        UPDATE newsletter_subscribers SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

CREATE TRIGGER IF NOT EXISTS update_contact_timestamp 
    AFTER UPDATE ON contact_submissions
    BEGIN
        UPDATE contact_submissions SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

CREATE TRIGGER IF NOT EXISTS update_beta_timestamp 
    AFTER UPDATE ON beta_signups
    BEGIN
        UPDATE beta_signups SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

CREATE TRIGGER IF NOT EXISTS update_sessions_timestamp 
    AFTER UPDATE ON user_sessions
    BEGIN
        UPDATE user_sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

CREATE TRIGGER IF NOT EXISTS update_features_timestamp 
    AFTER UPDATE ON feature_requests
    BEGIN
        UPDATE feature_requests SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

