-- PicMob Landing Page Database Seed Data
-- Initial data for development and testing

-- Insert sample app store reviews/ratings
INSERT OR REPLACE INTO app_reviews (platform, store, rating, review_count, average_rating, last_updated) VALUES
('windows', 'microsoft', 4.8, 1250, 4.8, datetime('now')),
('macos', 'apple', 4.9, 2100, 4.9, datetime('now')),
('ios', 'apple', 4.7, 3500, 4.7, datetime('now')),
('android', 'google', 4.6, 4200, 4.6, datetime('now'));

-- Insert sample download statistics (last 30 days)
INSERT OR REPLACE INTO downloads (platform, version, ip_address, user_agent, created_at) VALUES
('windows', '1.0.0', '192.168.1.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', datetime('now', '-1 day')),
('windows', '1.0.0', '192.168.1.2', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', datetime('now', '-1 day')),
('macos', '1.0.0', '192.168.1.3', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', datetime('now', '-2 days')),
('ios', '1.0.0', '192.168.1.4', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', datetime('now', '-3 days')),
('android', '1.0.0', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 14)', datetime('now', '-4 days')),
('windows', '1.0.0', '192.168.1.6', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', datetime('now', '-5 days')),
('macos', '1.0.0', '192.168.1.7', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', datetime('now', '-6 days')),
('ios', '1.0.0', '192.168.1.8', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', datetime('now', '-7 days')),
('android', '1.0.0', '192.168.1.9', 'Mozilla/5.0 (Linux; Android 14)', datetime('now', '-8 days')),
('windows', '1.0.0', '192.168.1.10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', datetime('now', '-9 days'));

-- Insert sample analytics events
INSERT OR REPLACE INTO analytics_events (event_name, properties, timestamp) VALUES
('page_view', '{"page": "/", "referrer": "google.com"}', datetime('now', '-1 hour')),
('page_view', '{"page": "/features", "referrer": "direct"}', datetime('now', '-2 hours')),
('download_click', '{"platform": "windows", "version": "1.0.0"}', datetime('now', '-3 hours')),
('newsletter_signup', '{"email": "user@example.com"}', datetime('now', '-4 hours')),
('beta_signup', '{"platform": "macos", "email": "beta@example.com"}', datetime('now', '-5 hours')),
('contact_form', '{"subject": "General Inquiry"}', datetime('now', '-6 hours')),
('scroll_depth', '{"depth": 75, "page": "/"}', datetime('now', '-7 hours')),
('video_play', '{"video": "demo", "duration": 30}', datetime('now', '-8 hours')),
('feature_click', '{"feature": "ai_upscaling"}', datetime('now', '-9 hours')),
('social_share', '{"platform": "twitter", "page": "/"}', datetime('now', '-10 hours'));

-- Insert sample feature requests
INSERT OR REPLACE INTO feature_requests (title, description, category, priority, status, votes, submitted_at) VALUES
('Batch Processing', 'Add ability to process multiple images at once', 'feature', 'high', 'in_progress', 45, datetime('now', '-7 days')),
('Cloud Sync', 'Sync settings and favorites across devices', 'feature', 'medium', 'open', 32, datetime('now', '-5 days')),
('RAW Support Improvement', 'Better support for Canon CR3 files', 'improvement', 'medium', 'open', 28, datetime('now', '-3 days')),
('Performance Issue', 'App crashes when opening large TIFF files', 'bug', 'high', 'in_progress', 15, datetime('now', '-2 days')),
('Dark Mode Toggle', 'Quick toggle between light and dark themes', 'feature', 'low', 'completed', 67, datetime('now', '-10 days')),
('Keyboard Shortcuts', 'More customizable keyboard shortcuts', 'improvement', 'medium', 'open', 23, datetime('now', '-4 days')),
('Export Quality', 'Higher quality export options for edited images', 'feature', 'medium', 'open', 19, datetime('now', '-6 days')),
('Memory Usage', 'High memory usage with multiple large images', 'bug', 'medium', 'in_progress', 12, datetime('now', '-1 day'));

-- Insert sample user sessions
INSERT OR REPLACE INTO user_sessions (session_id, ip_address, user_agent, referrer, landing_page, started_at, last_activity, page_views, duration_seconds) VALUES
('sess_001', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'https://google.com', '/', datetime('now', '-2 hours'), datetime('now', '-1 hour'), 5, 3600),
('sess_002', '192.168.1.101', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 'https://twitter.com', '/', datetime('now', '-3 hours'), datetime('now', '-2 hours'), 3, 1800),
('sess_003', '192.168.1.102', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', 'direct', '/features', datetime('now', '-1 hour'), datetime('now', '-30 minutes'), 2, 1200),
('sess_004', '192.168.1.103', 'Mozilla/5.0 (Linux; Android 14)', 'https://reddit.com', '/', datetime('now', '-4 hours'), datetime('now', '-3 hours'), 4, 2400),
('sess_005', '192.168.1.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'https://github.com', '/download', datetime('now', '-30 minutes'), datetime('now', '-10 minutes'), 1, 600);

-- Insert sample newsletter subscribers (for testing)
INSERT OR REPLACE INTO newsletter_subscribers (email, name, subscribed_at, status) VALUES
('test1@example.com', 'John Doe', datetime('now', '-10 days'), 'active'),
('test2@example.com', 'Jane Smith', datetime('now', '-8 days'), 'active'),
('test3@example.com', 'Bob Johnson', datetime('now', '-6 days'), 'active'),
('test4@example.com', 'Alice Brown', datetime('now', '-4 days'), 'unsubscribed'),
('test5@example.com', 'Charlie Wilson', datetime('now', '-2 days'), 'active');

-- Insert sample beta signups
INSERT OR REPLACE INTO beta_signups (email, platform, interests, signed_up_at, status) VALUES
('beta1@example.com', 'windows', '["ai_features", "performance"]', datetime('now', '-15 days'), 'active'),
('beta2@example.com', 'macos', '["ui_design", "workflow"]', datetime('now', '-12 days'), 'invited'),
('beta3@example.com', 'ios', '["mobile_editing", "sync"]', datetime('now', '-10 days'), 'pending'),
('beta4@example.com', 'android', '["performance", "formats"]', datetime('now', '-8 days'), 'pending'),
('beta5@example.com', 'all', '["ai_features", "ui_design", "performance"]', datetime('now', '-5 days'), 'invited');

-- Insert sample contact submissions
INSERT OR REPLACE INTO contact_submissions (name, email, subject, message, submitted_at, status) VALUES
('John Developer', 'john@example.com', 'API Integration', 'I would like to integrate PicMob with my workflow app.', datetime('now', '-3 days'), 'replied'),
('Sarah Designer', 'sarah@example.com', 'Feature Request', 'Could you add support for Sketch files?', datetime('now', '-2 days'), 'read'),
('Mike Photographer', 'mike@example.com', 'Bug Report', 'The app crashes when I try to edit RAW files from my Canon R5.', datetime('now', '-1 day'), 'new'),
('Lisa Student', 'lisa@example.com', 'Educational License', 'Do you offer educational discounts for students?', datetime('now', '-5 hours'), 'new');

