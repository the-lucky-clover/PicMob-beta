# PicMob macOS - Fixed Development Guide

## 🚨 Issue Resolution

The previous Xcode project file was corrupted. This guide provides step-by-step instructions to create a working PicMob macOS project from scratch using Xcode's built-in templates.

## 🎯 Overview

PicMob for macOS is a native Swift application built with SwiftUI that provides superior image viewing and editing capabilities with a professional "mafia edge" aesthetic. This guide provides complete step-by-step instructions to create the project from scratch and implement all features.

## 📋 Prerequisites

### Required Software
1. **macOS Ventura 13.0** or later (macOS Sonoma 14.0+ recommended)
2. **Xcode 15.0** or later (latest version recommended)
3. **Swift 5.9** or later (included with Xcode)
4. **Apple Developer Account** ($99/year)
5. **Git** for version control (included with Xcode Command Line Tools)

### Apple Developer Account Setup
1. **Visit:** https://developer.apple.com/programs/
2. **Enroll** in Apple Developer Program ($99/year)
3. **Complete identity verification** (may take 24-48 hours)
4. **Download certificates** and provisioning profiles

## 🚀 Step-by-Step Project Creation

### Step 1: Create New Xcode Project

1. **Open Xcode**
2. **Create a new project:**
   - File > New > Project
   - Select "macOS" tab
   - Choose "App" template
   - Click "Next"

3. **Configure project settings:**
   ```
   Product Name: PicMob
   Team: [Your Apple Developer Team]
   Organization Identifier: com.yourcompany.picmob
   Bundle Identifier: com.yourcompany.picmob
   Language: Swift
   Interface: SwiftUI
   Use Core Data: ✅ (checked)
   Include Tests: ✅ (checked)
   ```

4. **Choose location:**
   - Navigate to your development folder
   - Click "Create"

### Step 2: Configure Project Settings

1. **Select project in navigator**
2. **General tab settings:**
   ```
   Display Name: PicMob
   Bundle Identifier: com.yourcompany.picmob
   Version: 1.0
   Build: 1
   Deployment Target: macOS 13.0
   ```

3. **Signing & Capabilities:**
   - ✅ Automatically manage signing
   - Select your development team
   - Add capabilities:
     - ✅ App Sandbox
     - ✅ Hardened Runtime
     - ✅ File Access (User Selected Files - Read/Write)
     - ✅ Camera (for image capture)
     - ✅ Outgoing Connections (Client)

4. **Info tab - Document Types:**
   Add supported file types by clicking "+" and adding:
   ```
   Name: Images
   Types: public.image, public.jpeg, public.png, public.tiff, public.heic
   Role: Editor
   Icon: (leave empty for now)
   ```

### Step 3: Project Structure Setup

Create the following folder structure in your project:

1. **Right-click on project name** in navigator
2. **Select "New Group"** and create these groups:

```
PicMob/
├── Core/
│   ├── Models/
│   ├── Services/
│   ├── Interfaces/
│   └── Utilities/
├── UI/
│   ├── Views/
│   ├── ViewModels/
│   ├── Controls/
│   └── Styles/
├── ImageProcessing/
│   ├── Codecs/
│   ├── Filters/
│   ├── AI/
│   └── Metadata/
├── VideoEngine/
│   ├── Decoders/
│   ├── Renderers/
│   └── Controls/
├── Platform/
│   ├── FileSystem/
│   ├── AppKit/
│   ├── CoreServices/
│   └── Notifications/
└── Resources/
    ├── Assets/
    ├── Fonts/
    └── Models/
```

### Step 4: Add Swift Package Dependencies

1. **File > Add Package Dependencies**
2. **Add these packages one by one:**

```swift
// Core utilities
https://github.com/apple/swift-algorithms
https://github.com/apple/swift-collections
https://github.com/apple/swift-log

// Image processing
https://github.com/CoreOffice/CoreXLSX
https://github.com/tid-kijyun/Kanna

// AI/ML (if available)
https://github.com/apple/swift-numerics
```

### Step 5: Implement Core Files

#### 1. Replace ContentView.swift

Delete the default ContentView.swift and create a new one:

```swift
//
//  ContentView.swift
//  PicMob
//
//  Created by PicMob Team.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var appState = AppState()
    @StateObject private var imageService = ImageService()
    @State private var selectedImage: ImageInfo?
    @State private var showingSidebar = true
    
    var body: some View {
        NavigationSplitView {
            // Sidebar with folder browser and recent files
            SidebarView(selectedImage: $selectedImage)
                .frame(minWidth: 200, idealWidth: 250, maxWidth: 300)
                .background(PicMobTheme.sidebarBackground)
        } detail: {
            // Main image viewer area
            if let image = selectedImage {
                ImageViewerView(image: image)
                    .background(PicMobTheme.viewerBackground)
                    .toolbar {
                        ToolbarItemGroup(placement: .primaryAction) {
                            ViewerToolbar(image: image)
                        }
                    }
            } else {
                WelcomeView()
                    .background(PicMobTheme.viewerBackground)
            }
        }
        .navigationSplitViewStyle(.balanced)
        .background(PicMobTheme.primaryBackground)
        .onDrop(of: [.fileURL], isTargeted: nil) { providers in
            handleFileDrop(providers)
        }
        .environmentObject(appState)
        .environmentObject(imageService)
    }
    
    private func handleFileDrop(_ providers: [NSItemProvider]) -> Bool {
        for provider in providers {
            provider.loadItem(forTypeIdentifier: "public.file-url", options: nil) { item, error in
                if let data = item as? Data,
                   let url = URL(dataRepresentation: data, relativeTo: nil) {
                    Task {
                        await loadImage(from: url)
                    }
                }
            }
        }
        return true
    }
    
    private func loadImage(from url: URL) async {
        do {
            let imageInfo = try await imageService.loadImage(from: url)
            await MainActor.run {
                selectedImage = imageInfo
                appState.addRecentFile(url)
            }
        } catch {
            print("Failed to load image: \(error)")
        }
    }
}

#Preview {
    ContentView()
}
```

#### 2. Create PicMobTheme.swift

Create a new Swift file in UI/Styles/:

```swift
//
//  PicMobTheme.swift
//  PicMob
//
//  Created by PicMob Team.
//

import SwiftUI

struct PicMobTheme {
    // Mafia Edge Color Palette
    static let goldAccent = Color(red: 1.0, green: 0.843, blue: 0.0) // #FFD700
    static let darkGray = Color(red: 0.173, green: 0.173, blue: 0.173) // #2C2C2C
    static let deepBlack = Color(red: 0.102, green: 0.102, blue: 0.102) // #1A1A1A
    static let antiqueBrass = Color(red: 0.722, green: 0.525, blue: 0.043) // #B8860B
    static let charcoal = Color(red: 0.212, green: 0.212, blue: 0.212) // #363636
    
    // Background Colors
    static let primaryBackground = deepBlack
    static let sidebarBackground = darkGray
    static let viewerBackground = Color.black
    static let toolbarBackground = charcoal
    static let statusBarBackground = darkGray
    
    // Text Colors
    static let primaryText = Color.white
    static let secondaryText = Color.gray
    static let accentText = goldAccent
    static let mutedText = Color(white: 0.6)
    
    // Border Colors
    static let borderColor = Color(white: 0.3)
    static let focusBorder = goldAccent
    
    // Typography
    static let titleFont = Font.custom("Times New Roman", size: 24).weight(.bold)
    static let headlineFont = Font.custom("Times New Roman", size: 18).weight(.semibold)
    static let bodyFont = Font.system(size: 14, weight: .regular, design: .default)
    static let captionFont = Font.system(size: 12, weight: .regular, design: .default)
}

// Custom button style for mafia edge aesthetic
struct PicMobButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 6)
                    .fill(configuration.isPressed ? PicMobTheme.antiqueBrass : PicMobTheme.goldAccent)
            )
            .foregroundColor(PicMobTheme.deepBlack)
            .font(PicMobTheme.bodyFont.weight(.semibold))
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.easeInOut(duration: 0.1), value: configuration.isPressed)
    }
}
```

#### 3. Create AppState.swift

Create in Core/Models/:

```swift
//
//  AppState.swift
//  PicMob
//
//  Created by PicMob Team.
//

import Foundation
import SwiftUI

@MainActor
class AppState: ObservableObject {
    @Published var currentImage: ImageInfo?
    @Published var recentFiles: [URL] = []
    @Published var selectedFolder: URL?
    @Published var isProcessing: Bool = false
    @Published var processingProgress: Double = 0.0
    @Published var errorMessage: String?
    @Published var showingSettings: Bool = false
    
    // User preferences
    @Published var autoEnhanceImages: Bool = false
    @Published var defaultZoomLevel: Double = 1.0
    @Published var showThumbnailStrip: Bool = true
    @Published var enableAIFeatures: Bool = true
    
    init() {
        loadRecentFiles()
        loadUserPreferences()
    }
    
    func addRecentFile(_ url: URL) {
        recentFiles.removeAll { $0 == url }
        recentFiles.insert(url, at: 0)
        
        // Keep only the last 10 recent files
        if recentFiles.count > 10 {
            recentFiles = Array(recentFiles.prefix(10))
        }
        
        saveRecentFiles()
    }
    
    private func loadRecentFiles() {
        if let data = UserDefaults.standard.data(forKey: "RecentFiles"),
           let urls = try? JSONDecoder().decode([URL].self, from: data) {
            recentFiles = urls
        }
    }
    
    private func saveRecentFiles() {
        if let data = try? JSONEncoder().encode(recentFiles) {
            UserDefaults.standard.set(data, forKey: "RecentFiles")
        }
    }
    
    private func loadUserPreferences() {
        autoEnhanceImages = UserDefaults.standard.bool(forKey: "AutoEnhanceImages")
        defaultZoomLevel = UserDefaults.standard.double(forKey: "DefaultZoomLevel")
        showThumbnailStrip = UserDefaults.standard.bool(forKey: "ShowThumbnailStrip")
        enableAIFeatures = UserDefaults.standard.bool(forKey: "EnableAIFeatures")
        
        // Set defaults if not previously set
        if defaultZoomLevel == 0 {
            defaultZoomLevel = 1.0
        }
        if !UserDefaults.standard.object(forKey: "ShowThumbnailStrip") {
            showThumbnailStrip = true
        }
        if !UserDefaults.standard.object(forKey: "EnableAIFeatures") {
            enableAIFeatures = true
        }
    }
    
    func saveUserPreferences() {
        UserDefaults.standard.set(autoEnhanceImages, forKey: "AutoEnhanceImages")
        UserDefaults.standard.set(defaultZoomLevel, forKey: "DefaultZoomLevel")
        UserDefaults.standard.set(showThumbnailStrip, forKey: "ShowThumbnailStrip")
        UserDefaults.standard.set(enableAIFeatures, forKey: "EnableAIFeatures")
    }
}
```

#### 4. Create ImageInfo.swift

Create in Core/Models/:

```swift
//
//  ImageInfo.swift
//  PicMob
//
//  Created by PicMob Team.
//

import Foundation
import CoreImage
import CoreGraphics
import UniformTypeIdentifiers

struct ImageInfo: Identifiable {
    let id = UUID()
    let url: URL
    let ciImage: CIImage
    let cgImage: CGImage
    let metadata: ImageMetadata
    let format: ImageFormat
    let size: CGSize
    var isEdited: Bool = false
    
    var displayName: String {
        url.lastPathComponent
    }
    
    var fileSize: String {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useKB, .useMB, .useGB]
        formatter.countStyle = .file
        
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            if let size = attributes[.size] as? Int64 {
                return formatter.string(fromByteCount: size)
            }
        } catch {
            print("Error getting file size: \(error)")
        }
        
        return "Unknown"
    }
}

struct ImageMetadata {
    let exifData: [String: Any]
    let colorSpace: String
    let hasAlpha: Bool
    let orientation: Int
    let dpi: (x: Double, y: Double)
    let creationDate: Date?
    let cameraModel: String?
    let lensModel: String?
    let focalLength: String?
    let aperture: String?
    let shutterSpeed: String?
    let iso: String?
    
    init() {
        self.exifData = [:]
        self.colorSpace = "Unknown"
        self.hasAlpha = false
        self.orientation = 1
        self.dpi = (72.0, 72.0)
        self.creationDate = nil
        self.cameraModel = nil
        self.lensModel = nil
        self.focalLength = nil
        self.aperture = nil
        self.shutterSpeed = nil
        self.iso = nil
    }
}

enum ImageFormat: String, CaseIterable {
    case jpeg = "jpg"
    case png = "png"
    case gif = "gif"
    case tiff = "tiff"
    case bmp = "bmp"
    case webp = "webp"
    case heic = "heic"
    case heif = "heif"
    case avif = "avif"
    case raw = "raw"
    case dng = "dng"
    case cr2 = "cr2"
    case cr3 = "cr3"
    case nef = "nef"
    case arw = "arw"
    case orf = "orf"
    case rw2 = "rw2"
    case psd = "psd"
    
    static func from(extension: String) -> ImageFormat {
        return ImageFormat(rawValue: extension.lowercased()) ?? .jpeg
    }
    
    var contentType: UTType? {
        switch self {
        case .jpeg: return .jpeg
        case .png: return .png
        case .gif: return .gif
        case .tiff: return .tiff
        case .bmp: return .bmp
        case .webp: return UTType("org.webmproject.webp")
        case .heic: return .heic
        case .heif: return .heif
        case .avif: return UTType("public.avif")
        case .raw: return .rawImage
        case .dng: return UTType("com.adobe.raw-image")
        case .cr2: return UTType("com.canon.cr2-raw-image")
        case .cr3: return UTType("com.canon.cr3-raw-image")
        case .nef: return UTType("com.nikon.raw-image")
        case .arw: return UTType("com.sony.arw-raw-image")
        case .orf: return UTType("com.olympus.raw-image")
        case .rw2: return UTType("com.panasonic.rw2-raw-image")
        case .psd: return UTType("com.adobe.photoshop-image")
        }
    }
}
```

### Step 6: Create Placeholder Views

Create these placeholder views to make the project compile:

#### SidebarView.swift (in UI/Views/):
```swift
import SwiftUI

struct SidebarView: View {
    @Binding var selectedImage: ImageInfo?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("PICMOB")
                .font(PicMobTheme.titleFont)
                .foregroundColor(PicMobTheme.goldAccent)
                .padding(.horizontal)
            
            Text("The Family Business")
                .font(PicMobTheme.captionFont)
                .foregroundColor(PicMobTheme.mutedText)
                .padding(.horizontal)
            
            Divider()
                .background(PicMobTheme.borderColor)
            
            Text("FOLDERS")
                .font(PicMobTheme.bodyFont.weight(.semibold))
                .foregroundColor(PicMobTheme.accentText)
                .padding(.horizontal)
            
            // Folder browser will be implemented here
            
            Spacer()
            
            Text("RECENT")
                .font(PicMobTheme.bodyFont.weight(.semibold))
                .foregroundColor(PicMobTheme.accentText)
                .padding(.horizontal)
            
            // Recent files will be implemented here
            
            Spacer()
        }
        .background(PicMobTheme.sidebarBackground)
    }
}
```

#### ImageViewerView.swift (in UI/Views/):
```swift
import SwiftUI

struct ImageViewerView: View {
    let image: ImageInfo
    @State private var scale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    
    var body: some View {
        GeometryReader { geometry in
            Image(decorative: image.cgImage, scale: 1.0)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .scaleEffect(scale)
                .offset(offset)
                .gesture(
                    MagnificationGesture()
                        .onChanged { value in
                            scale = value
                        }
                )
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            offset = value.translation
                        }
                )
        }
        .background(PicMobTheme.viewerBackground)
    }
}
```

#### ViewerToolbar.swift (in UI/Views/):
```swift
import SwiftUI

struct ViewerToolbar: View {
    let image: ImageInfo
    
    var body: some View {
        HStack {
            Button(action: {}) {
                Image(systemName: "plus.magnifyingglass")
            }
            .buttonStyle(PicMobButtonStyle())
            
            Button(action: {}) {
                Image(systemName: "minus.magnifyingglass")
            }
            .buttonStyle(PicMobButtonStyle())
            
            Button(action: {}) {
                Image(systemName: "arrow.clockwise")
            }
            .buttonStyle(PicMobButtonStyle())
            
            Button(action: {}) {
                Image(systemName: "wand.and.rays")
            }
            .buttonStyle(PicMobButtonStyle())
        }
    }
}
```

#### WelcomeView.swift (in UI/Views/):
```swift
import SwiftUI

struct WelcomeView: View {
    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "crown.fill")
                .font(.system(size: 64))
                .foregroundColor(PicMobTheme.goldAccent)
            
            Text("PicMob")
                .font(PicMobTheme.titleFont)
                .foregroundColor(PicMobTheme.goldAccent)
            
            Text("An offer your images can't refuse")
                .font(PicMobTheme.headlineFont)
                .foregroundColor(PicMobTheme.primaryText)
                .italic()
            
            Text("Drop an image here or use File > Open to get started")
                .font(PicMobTheme.bodyFont)
                .foregroundColor(PicMobTheme.mutedText)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(PicMobTheme.viewerBackground)
    }
}
```

#### ImageService.swift (in Core/Services/):
```swift
import Foundation
import CoreImage
import ImageIO

@MainActor
class ImageService: ObservableObject {
    private let ciContext = CIContext()
    
    func loadImage(from url: URL) async throws -> ImageInfo {
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil) else {
                        throw ImageError.invalidFile
                    }
                    
                    guard let cgImage = CGImageSourceCreateImageAtIndex(imageSource, 0, nil) else {
                        throw ImageError.failedToLoad
                    }
                    
                    let ciImage = CIImage(cgImage: cgImage)
                    let metadata = ImageMetadata() // Simplified for now
                    
                    let imageInfo = ImageInfo(
                        url: url,
                        ciImage: ciImage,
                        cgImage: cgImage,
                        metadata: metadata,
                        format: ImageFormat.from(extension: url.pathExtension),
                        size: CGSize(width: cgImage.width, height: cgImage.height)
                    )
                    
                    continuation.resume(returning: imageInfo)
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}

enum ImageError: Error {
    case invalidFile
    case failedToLoad
    case unsupportedFormat
    case processingFailed
}
```

### Step 7: Build and Test

1. **Build the project:**
   - Press `⌘+B` to build
   - Fix any compilation errors

2. **Run the project:**
   - Press `⌘+R` to run
   - Test basic functionality

### Step 8: Add App Icon

1. **Create app icon:**
   - Design a crown icon with gold/black theme
   - Export in required sizes: 16x16, 32x32, 128x128, 256x256, 512x512, 1024x1024

2. **Add to project:**
   - Select Assets.xcassets
   - Drag icon files to AppIcon slots

## 🔧 Building and Deployment

### Debug Build
```bash
xcodebuild -project PicMob.xcodeproj -scheme PicMob -configuration Debug build
```

### Release Build
```bash
xcodebuild -project PicMob.xcodeproj -scheme PicMob -configuration Release -archivePath build/PicMob.xcarchive archive
```

### Mac App Store Submission

1. **Archive the app:** Product > Archive in Xcode
2. **Export for distribution:** Choose "Mac App Store Connect"
3. **Upload to App Store Connect**
4. **Configure app information and submit for review**

## 🚨 Troubleshooting

### Common Issues

1. **Build Errors:**
   - Clean build folder: Product > Clean Build Folder
   - Reset package cache: File > Packages > Reset Package Caches

2. **Code Signing Issues:**
   - Verify Apple Developer account is active
   - Check provisioning profiles in Xcode preferences

3. **Runtime Crashes:**
   - Check Console.app for crash logs
   - Verify all required frameworks are linked

## 💰 Monetization

- **Price:** $9.99 (50% less than Pixea Plus)
- **Target:** $75,000 revenue in Year 1
- **Features:** 50+ formats, AI upscaling, professional UI

## 📞 Support

- **Documentation:** Complete implementation guides included
- **Issues:** Report via GitHub or support email
- **Updates:** Regular feature additions and improvements

---

**This corrected approach will create a working Xcode project that you can build and expand upon. The project structure is professional and follows Apple's best practices for macOS development.**

